function [F, M, trpy, drpy] = controller(qd, t, qn, params)
% CONTROLLER quadrotor controller
% The current states are:
% qd{qn}.pos, qd{qn}.vel, qd{qn}.euler = [roll;pitch;yaw], qd{qn}.omega
% The desired states are:
% qd{qn}.pos_des, qd{qn}.vel_des, qd{qn}.acc_des, qd{qn}.yaw_des, qd{qn}.yawdot_des
% Using these current and desired states, you have to compute the desired controls

% =================== Your code goes here ===================

% Desired roll, pitch and yaw
psi_des = qd{qn}.yaw_des;

rpy = qd{qn}.euler; %phi theta and psi

ww_des = qd{qn}.vel_des;
pw_des = qd{qn}.pos_des;

kpp = [10;4;17]; %[5;4;20]; 
kdp = [5;6;9]; %[7;6;10];

kpa = [.1;.1;1];
kda = [.02;.02;1];

epos = (pw_des - qd{qn}.pos);
evel = (ww_des - qd{qn}.vel);
acc_des = (kpp .* epos) +(kdp .* evel) + qd{qn}.acc_des;

rp_des = ([sin(psi_des), -cos(psi_des);cos(psi_des), sin(psi_des)] * acc_des(1:2, 1)) ./ params.grav;

for ind = 1:length(rp_des)
    if abs(rp_des(ind)) > params.maxangle
        rp_des(ind) = sign(rp_des(ind)) * params.maxangle;
    end
end

phi_des = rp_des(1);
theta_des = rp_des(2);

% Thurst
F = (params.mass * (params.grav + acc_des(3)));


% Moment
% You should fill this in

rpy_des = [phi_des;theta_des;psi_des];

pqr_des = [0;0;qd{qn}.yawdot_des];

pqr = qd{qn}.omega;

M = ((kpa .* (rpy_des - rpy)) + (kda .* (pqr_des - pqr)));

% 
% =================== Your code ends here ===================

% Output trpy and drpy as in hardware
trpy = [F, phi_des, theta_des, psi_des];
drpy = [0, 0,       0,         0];

end
