function [desired_state] = diamond(t, qn)
% DIAMOND trajectory generator for a diamond

% =================== Your code goes here ===================
% You have to set the pos, vel, acc, yaw and yawdot variables

pos = [0; 0; 0];
vel = [0; 0; 0];
acc = [0; 0; 0];
yaw = 0;
yawdot = 0;
if qn == 1
    pos = [t1/(2*pi); abs(cos(t))*cos(t1); abs(sin(t))*sin(t)];
    vel = [ 1/(2*pi); 
        - abs(cos(t))*sin(t) - sign(cos(t))*cos(t)*sin(t); 
        abs(sin(t))*cos(t) + sign(sin(t))*cos(t)*sin(t)];
    
    acc = [0; 
        2*sign(cos(t))*sin(t)^2 - sign(cos(t))*cos(t)^2 - abs(cos(t))*cos(t) + 2*dirac(cos(t))*cos(t)*sin(t)^2;
        2*sign(sin(t))*cos(t)^2 - abs(sin(t))*sin(t) - sign(sin(t))*sin(t)^2 + 2*dirac(sin(t))*cos(t)^2*sin(t)];
end

if pos(1) > 1
    pos  = [1; 0; 0];
    vel = [0;0;0];
    acc = [0;0;0];
end

% =================== Your code ends here ===================

desired_state.pos = pos(:);
desired_state.vel = vel(:);
desired_state.acc = acc(:);
desired_state.yaw = yaw;
desired_state.yawdot = yawdot;

end
